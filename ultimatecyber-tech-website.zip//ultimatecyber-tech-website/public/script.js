// ULTIMATE CYBER-TECH LTD - Main JavaScript
// © 2024 Ultimate Cyber-Tech Ltd. All rights reserved.

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 ULTIMATE CYBER-TECH LTD website loaded');
    console.log('Building the Future, One Commit at a Time.');
    
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
            if (navLinks.style.display === 'flex') {
                navLinks.style.flexDirection = 'column';
                navLinks.style.position = 'absolute';
                navLinks.style.top = '100%';
                navLinks.style.left = '0';
                navLinks.style.right = '0';
                navLinks.style.background = 'white';
                navLinks.style.padding = '20px';
                navLinks.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
            }
        });
    }
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (window.innerWidth <= 768) {
                    navLinks.style.display = 'none';
                }
            }
        });
    });
    
    // Contact form handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // In a real app, you would send this to your server
            // For now, just show a success message
            alert('Thank you for your message! We will contact you soon.');
            this.reset();
            
            // Log the submission (for demo)
            console.log('📧 Form submitted:', {
                ...data,
                company: 'ULTIMATE CYBER-TECH LTD',
                timestamp: new Date().toISOString()
            });
        });
    }
    
    // Add active class to nav links on scroll
    const sections = document.querySelectorAll('section[id]');
    
    function highlightNavLink() {
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector(`.nav-links a[href*="${sectionId}"]`);
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight && navLink) {
                navLink.classList.add('active');
            } else if (navLink) {
                navLink.classList.remove('active');
            }
        });
    }
    
    window.addEventListener('scroll', highlightNavLink);
    
    // Add animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, observerOptions);
    
    // Observe elements to animate
    document.querySelectorAll('.service-card, .contact-item, .section-title').forEach(el => {
        observer.observe(el);
    });
    
    // Dynamic copyright year
    const copyrightElements = document.querySelectorAll('[data-year]');
    const currentYear = new Date().getFullYear();
    copyrightElements.forEach(el => {
        el.textContent = currentYear;
    });
    
    // Console greeting
    console.log('%c🚀 ULTIMATE CYBER-TECH LTD', 'color: #2563eb; font-size: 16px; font-weight: bold;');
    console.log('%cContact: 247assist@mail.com | +1 310 6018 952', 'color: #64748b;');
    console.log('%cBuilding the Future, One Commit at a Time.', 'color: #10b981;');
});