// ULTIMATE CYBER-TECH LTD - Header Component
// © 2024 Ultimate Cyber-Tech Ltd. All rights reserved.

import React, { useState } from 'react';
import './Header.css';

const Header = ({ company }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'services', label: 'Services', icon: '🛡️' },
    { id: 'about', label: 'About', icon: 'ℹ️' },
    { id: 'contact', label: 'Contact', icon: '📞' },
  ];

  const contactInfo = {
    email: company.email || '247assist@mail.com',
    phoneUS: company.phoneUS || '+1 310 6018 952',
    phoneUK: company.phoneUK || '+44 7862 126859',
    address: company.address || '225 S Olive St, Los Angeles, CA 90012'
  };

  const handleNavClick = (sectionId) => {
    setIsMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="ultimatecyber-header">
      <div className="header-container">
        {/* Logo Section */}
        <div className="logo-section">
          <div className="logo">
            <span className="logo-icon">🛡️</span>
            <div className="logo-text">
              <h1 className="logo-title">ULTIMATE CYBER-TECH</h1>
              <p className="logo-subtitle">Building the Future, One Commit at a Time</p>
            </div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="desktop-nav">
          <ul className="nav-list">
            {menuItems.map((item) => (
              <li key={item.id} className="nav-item">
                <button
                  onClick={() => handleNavClick(item.id)}
                  className="nav-link"
                >
                  <span className="nav-icon">{item.icon}</span>
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Contact Info */}
        <div className="contact-info-desktop">
          <div className="contact-item">
            <span className="contact-icon">📧</span>
            <div className="contact-details">
              <span className="contact-label">Email</span>
              <a href={`mailto:${contactInfo.email}`} className="contact-value">
                {contactInfo.email}
              </a>
            </div>
          </div>
          <button className="cta-button" onClick={() => handleNavClick('contact')}>
            Get Quote
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="mobile-menu-button"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          <span className={`menu-icon ${isMenuOpen ? 'open' : ''}`}>
            <span></span>
            <span></span>
            <span></span>
          </span>
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${isMenuOpen ? 'open' : ''}`}>
        <div className="mobile-menu-content">
          {/* Company Info */}
          <div className="mobile-company-info">
            <h3>ULTIMATE CYBER-TECH LTD</h3>
            <p>Building the Future, One Commit at a Time</p>
          </div>

          {/* Mobile Navigation */}
          <ul className="mobile-nav-list">
            {menuItems.map((item) => (
              <li key={item.id} className="mobile-nav-item">
                <button
                  onClick={() => handleNavClick(item.id)}
                  className="mobile-nav-link"
                >
                  <span className="mobile-nav-icon">{item.icon}</span>
                  <span className="mobile-nav-label">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>

          {/* Mobile Contact Info */}
          <div className="mobile-contact-info">
            <h4>Contact Us</h4>
            <div className="mobile-contact-items">
              <div className="mobile-contact-item">
                <span className="mobile-contact-icon">📧</span>
                <a href={`mailto:${contactInfo.email}`}>{contactInfo.email}</a>
              </div>
              <div className="mobile-contact-item">
                <span className="mobile-contact-icon">📱</span>
                <a href={`tel:${contactInfo.phoneUS.replace(/\s/g, '')}`}>
                  {contactInfo.phoneUS}
                </a>
              </div>
              <div className="mobile-contact-item">
                <span className="mobile-contact-icon">📍</span>
                <span>{contactInfo.address}</span>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="mobile-copyright">
            <p>© 2024 Ultimate Cyber-Tech Ltd. All rights reserved.</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;