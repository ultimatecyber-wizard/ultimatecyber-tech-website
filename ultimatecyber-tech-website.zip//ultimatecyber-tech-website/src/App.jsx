// ULTIMATE CYBER-TECH LTD - React App Component
// © 2024 Ultimate Cyber-Tech Ltd. All rights reserved.

import React from 'react';
import Header from './components/Header';

function App() {
  const companyInfo = {
    name: "ULTIMATE CYBER-TECH LTD",
    email: "247assist@mail.com",
    address: "225 S Olive St, Los Angeles, CA 90012",
    phoneUS: "+1 310 6018 952",
    phoneUK: "+44 7862 126859",
    copyright: "© 2024 Ultimate Cyber-Tech Ltd. All rights reserved.",
    tagline: "Building the Future, One Commit at a Time."
  };

  return (
    <div className="ultimatecyber-app">
      <Header company={companyInfo} />
      
      <main className="main-content">
        <section className="hero-section">
          <h1>{companyInfo.tagline}</h1>
          <p>Advanced cybersecurity and technology solutions</p>
          <button className="cta-button">Get Started</button>
        </section>
        
        <section className="contact-section">
          <h2>Contact Us</h2>
          <div className="contact-details">
            <p><strong>Email:</strong> {companyInfo.email}</p>
            <p><strong>Phone (US):</strong> {companyInfo.phoneUS}</p>
            <p><strong>Phone (UK):</strong> {companyInfo.phoneUK}</p>
            <p><strong>Address:</strong> {companyInfo.address}</p>
          </div>
        </section>
      </main>
      
      <footer className="app-footer">
        <p>{companyInfo.copyright}</p>
        <p>{companyInfo.tagline}</p>
      </footer>
    </div>
  );
}

export default App;